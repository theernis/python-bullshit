---this project is written in python so you will need to download and install python
--here is a link for downloading python: https://www.python.org/downloads/

---once python is set up run game.py file
--if file doesnt start run debug.bat
--if its missing module error install it trough cmd using "pip install module_name" command
-if it shows "'pip' is not recognized" this tutorial should help: https://www.youtube.com/watch?v=zYdHr-LxsJ0/

---some things i should mention
--"field" location only has traders and "forest" location has traders and fight
--your health is regenerated at start of each day
